import re
import json
from collections import Counter
import zlib

# Pre-built dictionary of words
def build_corpus():
    corpus = """
    going to china who was the first president of india winner of the match food in america
    india china usa america president first winner match food going
    """
    words = re.findall(r'\w+', corpus.lower())
    return Counter(words)

# Load compressed dictionary
def get_corpus():
    compressed_corpus = zlib.compress(json.dumps(build_corpus()).encode())
    return json.loads(zlib.decompress(compressed_corpus).decode())

# Calculate edit distance
def edit_distance(word1, word2):
    dp = [[0] * (len(word2) + 1) for _ in range(len(word1) + 1)]
    for i in range(len(word1) + 1):
        for j in range(len(word2) + 1):
            if i == 0:
                dp[i][j] = j
            elif j == 0:
                dp[i][j] = i
            elif word1[i - 1] == word2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
    return dp[-1][-1]

# Get candidate corrections
def correct(word, corpus):
    if word in corpus:
        return word
    candidates = [(w, edit_distance(word, w)) for w in corpus if edit_distance(word, w) <= 2]
    candidates.sort(key=lambda x: (x[1], -corpus[x[0]]))  # Sort by distance, then frequency
    return candidates[0][0] if candidates else word

# Correct a query
def correct_query(query, corpus):
    words = query.split()
    corrected = [correct(word, corpus) for word in words]
    return ' '.join(corrected)

# Main program
def main():
    # Input
    n = int(input())
    queries = [input().strip() for _ in range(n)]
    
    # Load dictionary
    corpus = get_corpus()
    
    # Correct queries
    corrected_queries = [correct_query(query, corpus) for query in queries]
    
    # Output
    for corrected in corrected_queries:
        print(corrected)

# Run program
if __name__ == "__main__":
    main()
